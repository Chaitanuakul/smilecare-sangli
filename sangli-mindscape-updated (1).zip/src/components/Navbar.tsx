import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Menu, X, Smile } from "lucide-react";
import AppointmentDialog from "./AppointmentDialog";
import WaitTimeIndicator from "./WaitTimeIndicator";

const Navbar = () => {
  const { t, toggle } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);
  const [aptOpen, setAptOpen] = useState(false);

  return (
    <>
      <nav className="sticky top-0 z-50 bg-card/95 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 flex items-center justify-between h-16">
          <a href="#" className="flex items-center gap-2">
            <Smile className="h-7 w-7 text-primary" />
            <span className="font-heading text-lg font-bold text-primary">{t("nav.clinic")}</span>
          </a>

          <div className="hidden md:flex items-center gap-3">
            <WaitTimeIndicator />
            <button
              onClick={toggle}
              className="px-3 py-1.5 text-sm font-medium rounded-md border border-border text-muted-foreground hover:bg-muted transition-colors"
            >
              {t("nav.lang")}
            </button>
            <Button onClick={() => setAptOpen(true)} className="gradient-primary text-primary-foreground font-semibold px-6">
              {t("nav.book")}
            </Button>
          </div>

          <div className="flex items-center gap-2 md:hidden">
            <WaitTimeIndicator />
            <button onClick={() => setMenuOpen(!menuOpen)} className="p-2" aria-label="Menu">
              {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="md:hidden bg-card border-b border-border px-4 pb-4 space-y-3">
            <button onClick={() => { toggle(); setMenuOpen(false); }} className="w-full py-2 text-sm font-medium rounded-md border border-border text-muted-foreground">
              {t("nav.lang")}
            </button>
            <Button onClick={() => { setAptOpen(true); setMenuOpen(false); }} className="w-full gradient-primary text-primary-foreground font-semibold">
              {t("nav.book")}
            </Button>
          </div>
        )}
      </nav>
      <AppointmentDialog open={aptOpen} onOpenChange={setAptOpen} />
    </>
  );
};

export default Navbar;
