import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import ba1 from "@/assets/before-after-1.jpg";
import ba2 from "@/assets/before-after-2.jpg";
import ba3 from "@/assets/before-after-3.jpg";
import BeforeAfterSlider from "./BeforeAfterSlider";

const images = [
  { before: ba1, after: ba2 },
  { before: ba2, after: ba3 },
  { before: ba3, after: ba1 },
];

const GallerySection = () => {
  const { t } = useLanguage();

  return (
    <section className="bg-sky py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary mb-3">{t("gallery.title")}</h2>
          <p className="text-muted-foreground text-lg">{t("gallery.subtitle")}</p>
        </div>
        <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {images.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.12, duration: 0.5 }}
            >
              <BeforeAfterSlider
                beforeImg={img.before}
                afterImg={img.after}
                beforeLabel={t("gallery.before")}
                afterLabel={t("gallery.after")}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
