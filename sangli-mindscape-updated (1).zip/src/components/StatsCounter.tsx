import { useLanguage } from "@/contexts/LanguageContext";
import { motion, useInView } from "framer-motion";
import { Users, Award, ShieldCheck } from "lucide-react";
import { useRef, useState, useEffect } from "react";

function useCountUp(target: number, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);
  return count;
}

const StatsCounter = () => {
  const { t } = useLanguage();
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });

  const stats = [
    { icon: Users, target: 500, suffix: "+", label: t("stats.patients") },
    { icon: Award, target: 10, suffix: "+", label: t("stats.experience") },
    { icon: ShieldCheck, target: 98, suffix: "%", label: t("stats.painless") },
  ];

  return (
    <section ref={ref} className="bg-sky py-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-3 gap-4 max-w-3xl mx-auto">
          {stats.map((s, i) => (
            <CountStat key={i} icon={s.icon} target={s.target} suffix={s.suffix} label={s.label} inView={inView} delay={i * 200} />
          ))}
        </div>
      </div>
    </section>
  );
};

function CountStat({ icon: Icon, target, suffix, label, inView, delay }: {
  icon: React.ElementType; target: number; suffix: string; label: string; inView: boolean; delay: number;
}) {
  const [started, setStarted] = useState(false);
  useEffect(() => {
    if (inView) {
      const timer = setTimeout(() => setStarted(true), delay);
      return () => clearTimeout(timer);
    }
  }, [inView, delay]);
  const count = useCountUp(target, 1500, started);

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ delay: delay / 1000, duration: 0.4 }}
      className="text-center"
    >
      <Icon className="h-8 w-8 text-primary mx-auto mb-2" />
      <div className="font-heading text-2xl sm:text-3xl font-extrabold text-primary">{count}{suffix}</div>
      <div className="text-sm text-muted-foreground font-medium">{label}</div>
    </motion.div>
  );
}

export default StatsCounter;
