import { useLanguage } from "@/contexts/LanguageContext";
import { CalendarPlus, Phone, MessageCircle, MapPin } from "lucide-react";
import { useState } from "react";
import { useClinicStore } from "@/stores/clinicStore";
import AppointmentDialog from "./AppointmentDialog";

const QuickLinksBar = () => {
  const { t } = useLanguage();
  const [store] = useClinicStore();
  const [aptOpen, setAptOpen] = useState(false);

  const waMessage = encodeURIComponent("Hi, I'd like to book an appointment at SmileCare Dental Clinic, Sangli.");

  const links = [
    { label: t("ql.book"), icon: CalendarPlus, onClick: () => setAptOpen(true) },
    { label: t("ql.call"), icon: Phone, href: `tel:${store.phone}` },
    { label: t("ql.whatsapp"), icon: MessageCircle, href: `https://wa.me/${store.whatsapp}?text=${waMessage}` },
    { label: t("ql.map"), icon: MapPin, href: "https://maps.google.com/?q=Sangli+Maharashtra" },
  ];

  return (
    <>
      <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden gradient-primary border-t border-primary-foreground/10">
        <div className="grid grid-cols-4">
          {links.map((link) => {
            const Icon = link.icon;
            const cls = "flex flex-col items-center gap-1 py-3 text-primary-foreground text-xs font-medium hover:bg-primary-foreground/10 transition-colors";
            if (link.href) {
              return (
                <a key={link.label} href={link.href} target="_blank" rel="noopener noreferrer" className={cls}>
                  <Icon className="h-5 w-5" /> {link.label}
                </a>
              );
            }
            return (
              <button key={link.label} onClick={link.onClick} className={cls}>
                <Icon className="h-5 w-5" /> {link.label}
              </button>
            );
          })}
        </div>
      </div>
      <AppointmentDialog open={aptOpen} onOpenChange={setAptOpen} />
    </>
  );
};

export default QuickLinksBar;
