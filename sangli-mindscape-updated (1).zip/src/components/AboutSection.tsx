import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { GraduationCap, Clock } from "lucide-react";
import dentistPhoto from "@/assets/dentist-photo.jpg";

const AboutSection = () => {
  const { t } = useLanguage();

  return (
    <section id="about" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary text-center mb-12">{t("about.title")}</h2>
        <div className="grid md:grid-cols-2 gap-10 items-center max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="flex justify-center"
          >
            <div className="w-64 h-72 md:w-72 md:h-80 rounded-2xl overflow-hidden shadow-card-hover border-4 border-secondary/30">
              <img src={dentistPhoto} alt={t("about.name")} className="w-full h-full object-cover" loading="lazy" width={512} height={640} />
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="font-heading text-2xl font-bold text-primary mb-1">{t("about.name")}</h3>
            <div className="flex flex-wrap gap-3 mb-4">
              <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <GraduationCap className="h-4 w-4 text-secondary" /> {t("about.qual")}
              </span>
              <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Clock className="h-4 w-4 text-secondary" /> {t("about.exp")}
              </span>
            </div>
            <p className="text-muted-foreground leading-relaxed">{t("about.bio")}</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
