import { useLanguage } from "@/contexts/LanguageContext";
import { useClinicStore } from "@/stores/clinicStore";
import { Smile, Clock, MapPin, Phone, MessageCircle } from "lucide-react";

const Footer = () => {
  const { t } = useLanguage();
  const [store] = useClinicStore();
  const waMessage = encodeURIComponent("Hi, I'd like to book an appointment at SmileCare Dental Clinic, Sangli.");

  return (
    <footer className="bg-foreground text-background py-12 pb-24 md:pb-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Smile className="h-6 w-6 text-secondary" />
              <span className="font-heading text-xl font-bold">{t("nav.clinic")}</span>
            </div>
            <p className="text-background/60 text-sm leading-relaxed">{t("hero.subtitle")}</p>
          </div>
          <div>
            <h4 className="font-heading text-lg font-semibold mb-4 flex items-center gap-2">
              <Clock className="h-5 w-5 text-secondary" /> Timings
            </h4>
            <p className="text-background/70 text-sm mb-1">{t("footer.timing")}</p>
            <p className="text-background/70 text-sm">{t("footer.sunday")}</p>
          </div>
          <div>
            <h4 className="font-heading text-lg font-semibold mb-4">Contact</h4>
            <div className="space-y-2 text-sm">
              <a href={`tel:${store.phone}`} className="flex items-center gap-2 text-background/70 hover:text-background transition-colors">
                <Phone className="h-4 w-4 text-secondary" /> {store.phone}
              </a>
              <a href={`https://wa.me/${store.whatsapp}?text=${waMessage}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-background/70 hover:text-background transition-colors">
                <MessageCircle className="h-4 w-4 text-secondary" /> WhatsApp
              </a>
              <p className="flex items-start gap-2 text-background/70">
                <MapPin className="h-4 w-4 mt-0.5 shrink-0 text-secondary" /> {t("footer.address")}
              </p>
            </div>
          </div>
        </div>
        <div className="border-t border-background/10 pt-6 text-center">
          <p className="text-background/40 text-sm">© {new Date().getFullYear()} {t("nav.clinic")}. {t("footer.rights")}.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
