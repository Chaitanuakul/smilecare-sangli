import { useLanguage } from "@/contexts/LanguageContext";
import { useClinicStore, isClinicOpen } from "@/stores/clinicStore";
import { Clock } from "lucide-react";

const WaitTimeIndicator = () => {
  const { t } = useLanguage();
  const [store] = useClinicStore();
  const open = isClinicOpen();

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted text-xs font-medium">
      {open ? (
        <>
          <span className="w-2 h-2 rounded-full bg-secondary animate-pulse-dot" />
          <Clock className="h-3 w-3 text-muted-foreground" />
          <span className="text-foreground">{t("wait.today")}: ~{store.waitTime} {t("wait.mins")}</span>
        </>
      ) : (
        <>
          <span className="w-2 h-2 rounded-full bg-destructive" />
          <span className="text-muted-foreground">{t("wait.closed")}</span>
        </>
      )}
    </div>
  );
};

export default WaitTimeIndicator;
