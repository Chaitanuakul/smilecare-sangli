import { useLanguage } from "@/contexts/LanguageContext";
import { useClinicStore } from "@/stores/clinicStore";
import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";
import { motion } from "framer-motion";
import heroDental from "@/assets/hero-dental.jpg";
import { useState } from "react";
import AppointmentDialog from "./AppointmentDialog";

const HeroSection = () => {
  const { t } = useLanguage();
  const [store] = useClinicStore();
  const [aptOpen, setAptOpen] = useState(false);

  return (
    <>
      <section className="relative min-h-[85vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroDental})` }} />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/40" />

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-xl">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-extrabold text-primary leading-tight mb-4">
                {t("hero.tagline")}
              </h1>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">{t("hero.subtitle")}</p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button onClick={() => setAptOpen(true)} size="lg"
                  className="bg-accent-warm hover:bg-accent-warm/90 text-accent-warm-foreground font-bold px-8 py-6 text-base rounded-xl">
                  {t("hero.cta")}
                </Button>
                <Button variant="outline" size="lg"
                  className="px-8 py-6 text-base rounded-xl border-primary text-primary hover:bg-primary hover:text-primary-foreground font-semibold"
                  asChild>
                  <a href={`tel:${store.phone}`}>
                    <Phone className="mr-2 h-5 w-5" />{t("hero.call")}
                  </a>
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      <AppointmentDialog open={aptOpen} onOpenChange={setAptOpen} />
    </>
  );
};

export default HeroSection;
