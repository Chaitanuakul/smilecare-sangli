import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { ShieldCheck, Cpu, IndianRupee } from "lucide-react";

const WhyChooseUs = () => {
  const { t } = useLanguage();

  const items = [
    { icon: ShieldCheck, key: "painless" },
    { icon: Cpu, key: "modern" },
    { icon: IndianRupee, key: "affordable" },
  ];

  return (
    <section className="bg-sky py-16 md:py-24">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary text-center mb-12">{t("why.title")}</h2>
        <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {items.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.key}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.4 }}
                className="bg-card rounded-xl p-6 text-center shadow-card border border-border/50"
              >
                <div className="w-14 h-14 rounded-full gradient-primary flex items-center justify-center mx-auto mb-4">
                  <Icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <h3 className="font-heading text-lg font-semibold text-foreground mb-2">{t(`why.${item.key}`)}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{t(`why.${item.key}Desc`)}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
