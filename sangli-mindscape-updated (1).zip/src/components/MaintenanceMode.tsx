import { useLanguage } from "@/contexts/LanguageContext";
import { useClinicStore } from "@/stores/clinicStore";
import { Wrench, Phone } from "lucide-react";

const MaintenanceMode = () => {
  const { t } = useLanguage();
  const [store] = useClinicStore();

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4">
      <div className="text-center max-w-sm">
        <Wrench className="h-16 w-16 text-primary mx-auto mb-6 animate-pulse" />
        <h1 className="font-heading text-3xl font-bold text-foreground mb-3">{t("maintenance.title")}</h1>
        <p className="text-muted-foreground mb-6">{t("maintenance.subtitle")}</p>
        <a
          href={`tel:${store.phone}`}
          className="inline-flex items-center gap-2 gradient-primary text-primary-foreground px-6 py-3 rounded-xl font-semibold"
        >
          <Phone className="h-5 w-5" /> {store.phone}
        </a>
      </div>
    </div>
  );
};

export default MaintenanceMode;
