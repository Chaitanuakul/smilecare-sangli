import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Stethoscope, Sparkles, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import AppointmentDialog from "./AppointmentDialog";

const symptomServiceMap: Record<string, string> = {
  pain: "rootcanal",
  straight: "braces",
  gums: "cleaning",
  checkup: "checkup",
  kidsprob: "kids",
  broken: "implant",
};

const SymptomHelper = () => {
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [typing, setTyping] = useState(false);
  const [aptOpen, setAptOpen] = useState(false);
  const [prefilledService, setPrefilledService] = useState("");

  const options = ["pain", "straight", "gums", "checkup", "kidsprob", "broken"];

  const handleSelect = (option: string) => {
    setSelected(null);
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setSelected(option);
    }, 1200);
  };

  const handleBook = (option: string) => {
    setPrefilledService(symptomServiceMap[option] || "checkup");
    setAptOpen(true);
    setOpen(false);
    setSelected(null);
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-20 md:bottom-6 right-4 z-40 w-14 h-14 rounded-full bg-accent-warm text-accent-warm-foreground shadow-float flex items-center justify-center hover:scale-110 transition-transform"
        aria-label="SmileCare Assistant"
      >
        {open ? <X className="h-6 w-6" /> : (
          <div className="relative">
            <Stethoscope className="h-6 w-6" />
            <Sparkles className="h-3 w-3 absolute -top-1 -right-1" />
          </div>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-36 md:bottom-24 right-4 z-40 w-80 bg-card rounded-2xl shadow-float border border-border overflow-hidden"
          >
            <div className="gradient-primary px-4 py-3">
              <h3 className="text-primary-foreground font-heading font-semibold text-sm">{t("symptom.title")}</h3>
            </div>

            <div className="p-4 max-h-80 overflow-y-auto">
              {/* Greeting */}
              <div className="bg-muted rounded-lg px-3 py-2 text-sm mb-3">{t("symptom.greeting")}</div>

              {/* Options */}
              {!selected && !typing && (
                <div className="flex flex-wrap gap-2 mb-3">
                  {options.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => handleSelect(opt)}
                      className="px-3 py-1.5 bg-primary/10 text-primary text-xs font-medium rounded-full hover:bg-primary/20 transition-colors"
                    >
                      {t(`symptom.${opt}`)}
                    </button>
                  ))}
                </div>
              )}

              {/* Typing indicator */}
              {typing && (
                <div className="bg-muted rounded-lg px-4 py-3 mb-3 flex gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="w-2 h-2 bg-muted-foreground rounded-full"
                      style={{
                        animation: `typing-dot 1.4s ease-in-out ${i * 0.2}s infinite`,
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Response */}
              {selected && !typing && (
                <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}>
                  <div className="bg-muted rounded-lg px-3 py-2 text-sm mb-3">
                    {t(`symptom.${selected}Reply`)}
                  </div>
                  <button
                    onClick={() => handleBook(selected)}
                    className="w-full text-center text-sm font-semibold text-accent-warm hover:underline"
                  >
                    {t("symptom.book")}
                  </button>
                  <button
                    onClick={() => setSelected(null)}
                    className="w-full text-center text-xs text-muted-foreground mt-2 hover:underline"
                  >
                    ← Ask another question
                  </button>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AppointmentDialog open={aptOpen} onOpenChange={setAptOpen} prefilledService={prefilledService} />

      <style>{`
        @keyframes typing-dot {
          0%, 60%, 100% { opacity: 0.3; transform: scale(0.8); }
          30% { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </>
  );
};

export default SymptomHelper;
