import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { CalendarPlus, MapPin, Stethoscope, Wrench, HeartPulse } from "lucide-react";

const steps = [
  { key: "1", icon: CalendarPlus },
  { key: "2", icon: MapPin },
  { key: "3", icon: Stethoscope },
  { key: "4", icon: Wrench },
  { key: "5", icon: HeartPulse },
];

const PatientJourney = () => {
  const { t } = useLanguage();

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary text-center mb-12">
          {t("journey.title")}
        </h2>

        {/* Desktop horizontal timeline */}
        <div className="hidden md:flex items-start justify-center gap-0 max-w-5xl mx-auto relative">
          {steps.map((step, i) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.key}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.4 }}
                className="flex-1 flex flex-col items-center text-center relative"
              >
                {/* Connector line */}
                {i < steps.length - 1 && (
                  <div className="absolute top-6 left-[50%] w-full h-0.5 bg-border z-0" />
                )}
                <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center z-10 mb-3">
                  <Icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="font-heading font-semibold text-sm mb-1">{t(`journey.${step.key}.title`)}</h3>
                <p className="text-xs text-muted-foreground px-2">{t(`journey.${step.key}.desc`)}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Mobile horizontal scroll */}
        <div className="md:hidden overflow-x-auto pb-4">
          <div className="flex gap-4 min-w-max px-2">
            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={step.key}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                  className="flex flex-col items-center text-center w-32 shrink-0"
                >
                  <div className="w-11 h-11 rounded-full gradient-primary flex items-center justify-center mb-2">
                    <Icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <h3 className="font-heading font-semibold text-xs mb-0.5">{t(`journey.${step.key}.title`)}</h3>
                  <p className="text-[11px] text-muted-foreground">{t(`journey.${step.key}.desc`)}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default PatientJourney;
