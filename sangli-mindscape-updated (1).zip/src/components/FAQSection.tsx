import { useLanguage } from "@/contexts/LanguageContext";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqs = [1, 2, 3, 4, 5];

const FAQSection = () => {
  const { t } = useLanguage();

  return (
    <section id="faq" className="py-16 md:py-24 bg-card">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary text-center mb-12">
          {t("faq.title")}
        </h2>
        <div className="max-w-2xl mx-auto">
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((n) => (
              <AccordionItem
                key={n}
                value={`faq-${n}`}
                className="bg-background rounded-lg px-5 border border-border"
              >
                <AccordionTrigger className="text-left font-medium text-foreground hover:text-primary py-4">
                  {t(`faq.${n}.q`)}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  {t(`faq.${n}.a`)}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
