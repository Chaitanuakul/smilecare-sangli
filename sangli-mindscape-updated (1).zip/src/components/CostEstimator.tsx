import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useClinicStore } from "@/stores/clinicStore";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import { IndianRupee, Calculator } from "lucide-react";
import AppointmentDialog from "./AppointmentDialog";

const treatmentLabels: Record<string, string> = {
  cleaning: "apt.cleaning",
  rootcanal: "apt.rootcanal",
  braces: "apt.braces",
  implants: "apt.implant",
  whitening: "svc.whitening",
  kids: "apt.kids",
  checkup: "apt.checkup",
};

const CostEstimator = () => {
  const { t } = useLanguage();
  const [store] = useClinicStore();
  const [selected, setSelected] = useState("");
  const [aptOpen, setAptOpen] = useState(false);

  const price = selected ? store.treatmentPrices[selected] : null;

  return (
    <>
      <section className="py-16 md:py-24 bg-sky">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-lg mx-auto text-center"
          >
            <div className="w-14 h-14 rounded-full bg-accent-warm flex items-center justify-center mx-auto mb-4">
              <Calculator className="h-7 w-7 text-accent-warm-foreground" />
            </div>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary mb-2">{t("cost.title")}</h2>
            <p className="text-muted-foreground mb-8">{t("cost.subtitle")}</p>

            <Select value={selected} onValueChange={setSelected}>
              <SelectTrigger className="w-full max-w-xs mx-auto">
                <SelectValue placeholder={t("cost.select")} />
              </SelectTrigger>
              <SelectContent>
                {Object.keys(store.treatmentPrices).map((key) => (
                  <SelectItem key={key} value={key}>{t(treatmentLabels[key] || key)}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {price && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mt-6 bg-card rounded-xl p-6 shadow-card border border-border"
              >
                <p className="text-sm text-muted-foreground mb-2">{t("cost.range")}</p>
                <p className="font-heading text-3xl font-bold text-primary flex items-center justify-center gap-1">
                  <IndianRupee className="h-6 w-6" />
                  {price.min.toLocaleString("en-IN")} – {price.max.toLocaleString("en-IN")}
                </p>
                <p className="text-xs text-muted-foreground mt-3">{t("cost.disclaimer")}</p>
                <Button
                  onClick={() => setAptOpen(true)}
                  className="mt-4 bg-accent-warm hover:bg-accent-warm/90 text-accent-warm-foreground font-semibold"
                >
                  {t("cost.book")}
                </Button>
              </motion.div>
            )}
          </motion.div>
        </div>
      </section>
      <AppointmentDialog open={aptOpen} onOpenChange={setAptOpen} prefilledService={selected} />
    </>
  );
};

export default CostEstimator;
