import { useState, useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { updateStore, getStore } from "@/stores/clinicStore";
import { motion, AnimatePresence } from "framer-motion";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  prefilledService?: string;
}

const moods = [
  { key: "nervous", emoji: "😰" },
  { key: "excited", emoji: "😊" },
  { key: "unsure", emoji: "😐" },
  { key: "justdoit", emoji: "😤" },
];

const AppointmentDialog = ({ open, onOpenChange, prefilledService = "" }: Props) => {
  const { t } = useLanguage();
  const [step, setStep] = useState<"mood" | "message" | "form">("mood");
  const [selectedMood, setSelectedMood] = useState("");
  const [form, setForm] = useState({ name: "", phone: "", service: prefilledService, time: "" });

  useEffect(() => {
    if (open) {
      setStep(prefilledService ? "form" : "mood");
      setSelectedMood("");
      setForm({ name: "", phone: "", service: prefilledService, time: "" });
    }
  }, [open, prefilledService]);

  const handleMoodSelect = (mood: string) => {
    setSelectedMood(mood);
    setStep("message");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.service || !form.time) return;
    const store = getStore();
    const appointment = {
      id: Date.now().toString(),
      name: form.name,
      phone: form.phone,
      service: form.service,
      time: form.time,
      date: new Date().toISOString().split("T")[0],
      status: "pending" as const,
      mood: selectedMood,
      createdAt: new Date().toISOString(),
    };
    updateStore({ appointments: [...store.appointments, appointment] });
    toast.success(t("apt.success"));
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-card">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl text-primary">{t("apt.title")}</DialogTitle>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {step === "mood" && (
            <motion.div key="mood" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-2">
              <p className="text-muted-foreground text-sm mb-4">{t("mood.title")}</p>
              <div className="grid grid-cols-2 gap-3">
                {moods.map((m) => (
                  <button
                    key={m.key}
                    onClick={() => handleMoodSelect(m.key)}
                    className="flex items-center gap-2 p-3 rounded-xl border border-border hover:border-primary hover:bg-primary/5 transition-all text-left"
                  >
                    <span className="text-2xl">{m.emoji}</span>
                    <span className="text-sm font-medium">{t(`mood.${m.key}`)}</span>
                  </button>
                ))}
              </div>
              <button onClick={() => setStep("form")} className="text-xs text-muted-foreground mt-3 hover:underline">
                Skip →
              </button>
            </motion.div>
          )}

          {step === "message" && (
            <motion.div key="message" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mt-2">
              <div className="bg-muted rounded-xl p-4 text-sm leading-relaxed mb-4">
                {t(`mood.${selectedMood}Msg`)}
              </div>
              <Button onClick={() => setStep("form")} className="w-full gradient-primary text-primary-foreground font-semibold">
                {t("mood.continue")}
              </Button>
            </motion.div>
          )}

          {step === "form" && (
            <motion.div key="form" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <form onSubmit={handleSubmit} className="space-y-4 mt-2">
                <div className="space-y-1.5">
                  <Label>{t("apt.name")}</Label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder={t("apt.namePh")} required />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("apt.phone")}</Label>
                  <Input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder={t("apt.phonePh")} required />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("apt.service")}</Label>
                  <Select value={form.service} onValueChange={(v) => setForm({ ...form, service: v })}>
                    <SelectTrigger><SelectValue placeholder={t("apt.servicePh")} /></SelectTrigger>
                    <SelectContent>
                      {["cleaning", "braces", "rootcanal", "implant", "checkup", "kids"].map((s) => (
                        <SelectItem key={s} value={s}>{t(`apt.${s}`)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>{t("apt.time")}</Label>
                  <Select value={form.time} onValueChange={(v) => setForm({ ...form, time: v })}>
                    <SelectTrigger><SelectValue placeholder={t("apt.timePh")} /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">{t("apt.morning")}</SelectItem>
                      <SelectItem value="evening">{t("apt.evening")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full gradient-primary text-primary-foreground font-semibold text-base py-5">
                  {t("apt.submit")}
                </Button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
};

export default AppointmentDialog;
