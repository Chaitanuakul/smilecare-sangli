import { useLanguage } from "@/contexts/LanguageContext";
import { useClinicStore } from "@/stores/clinicStore";
import { Phone } from "lucide-react";

const EmergencyBanner = () => {
  const { t } = useLanguage();
  const [store] = useClinicStore();

  if (!store.emergencyEnabled) return null;

  return (
    <div className="gradient-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-2 flex items-center justify-center gap-2 text-sm font-medium">
        <Phone className="h-4 w-4 animate-pulse" />
        <span>{t("emergency.text")}</span>
        <a href={`tel:${store.phone}`} className="underline font-bold ml-1 hover:opacity-80">
          {store.phone.replace(/(\d{2})(\d{5})(\d{5})/, "+$1 $2 $3")}
        </a>
      </div>
    </div>
  );
};

export default EmergencyBanner;
