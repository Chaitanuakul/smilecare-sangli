import { useState, useRef, useCallback } from "react";

interface Props {
  beforeImg: string;
  afterImg: string;
  beforeLabel: string;
  afterLabel: string;
}

const BeforeAfterSlider = ({ beforeImg, afterImg, beforeLabel, afterLabel }: Props) => {
  const [position, setPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const updatePosition = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    setPosition((x / rect.width) * 100);
  }, []);

  const handleMouseDown = () => { isDragging.current = true; };
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isDragging.current) updatePosition(e.clientX);
  }, [updatePosition]);
  const handleMouseUp = () => { isDragging.current = false; };

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    updatePosition(e.touches[0].clientX);
  }, [updatePosition]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-48 sm:h-56 rounded-xl overflow-hidden cursor-col-resize select-none shadow-card"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchMove={handleTouchMove}
    >
      {/* After (full) */}
      <img src={afterImg} alt="After" className="absolute inset-0 w-full h-full object-cover" loading="lazy" />

      {/* Before (clipped) */}
      <div className="absolute inset-0 overflow-hidden" style={{ width: `${position}%` }}>
        <img src={beforeImg} alt="Before" className="w-full h-full object-cover" style={{ width: containerRef.current?.offsetWidth || "100%", maxWidth: "none" }} loading="lazy" />
      </div>

      {/* Divider line */}
      <div
        className="absolute top-0 bottom-0 w-0.5 bg-primary-foreground shadow-lg z-10"
        style={{ left: `${position}%`, transform: "translateX(-50%)" }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleMouseDown}
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-primary-foreground shadow-float flex items-center justify-center">
          <svg className="w-4 h-4 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M8 5l-5 7 5 7M16 5l5 7-5 7" />
          </svg>
        </div>
      </div>

      {/* Labels */}
      <span className="absolute top-2 left-2 bg-foreground/70 text-background text-xs px-2 py-0.5 rounded-full font-medium z-10">
        {beforeLabel}
      </span>
      <span className="absolute top-2 right-2 bg-foreground/70 text-background text-xs px-2 py-0.5 rounded-full font-medium z-10">
        {afterLabel}
      </span>
    </div>
  );
};

export default BeforeAfterSlider;
