import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useClinicStore, updateStore } from "@/stores/clinicStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Star } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

const ReviewWidget = () => {
  const { t } = useLanguage();
  const [store] = useClinicStore();
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [name, setName] = useState("");
  const [comment, setComment] = useState("");

  const avgRating = store.reviews.length > 0
    ? (store.reviews.reduce((s, r) => s + r.rating, 0) / store.reviews.length).toFixed(1)
    : "0";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rating || !name.trim()) return toast.error("Please add your name and rating");
    const review = {
      id: Date.now().toString(),
      name: name.trim(),
      text: comment.trim(),
      rating,
      date: new Date().toISOString().split("T")[0],
    };
    updateStore({ reviews: [...store.reviews, review] });
    toast.success(t("review.success"));
    setRating(0);
    setName("");
    setComment("");
  };

  return (
    <section className="py-16 md:py-24 bg-sky">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-md mx-auto text-center"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary mb-2">{t("review.title")}</h2>

          {store.reviews.length > 0 && (
            <div className="flex items-center justify-center gap-2 mb-6">
              <div className="flex gap-0.5">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className={`h-5 w-5 ${s <= Math.round(Number(avgRating)) ? "fill-secondary text-secondary" : "text-border"}`} />
                ))}
              </div>
              <span className="font-heading font-bold text-lg text-foreground">{avgRating}</span>
              <span className="text-sm text-muted-foreground">({store.reviews.length} {t("review.title").toLowerCase().includes("rate") ? "reviews" : "reviews"})</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="bg-card rounded-xl p-6 shadow-card border border-border text-left space-y-4">
            {/* Star selector */}
            <div className="flex justify-center gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onMouseEnter={() => setHover(s)}
                  onMouseLeave={() => setHover(0)}
                  onClick={() => setRating(s)}
                  className="p-1"
                >
                  <Star className={`h-8 w-8 transition-colors ${
                    s <= (hover || rating) ? "fill-secondary text-secondary" : "text-border"
                  }`} />
                </button>
              ))}
            </div>

            <Input placeholder={t("review.name")} value={name} onChange={(e) => setName(e.target.value)} required />
            <Textarea placeholder={t("review.comment")} value={comment} onChange={(e) => setComment(e.target.value)} rows={2} />
            <Button type="submit" className="w-full gradient-primary text-primary-foreground font-semibold">
              {t("review.submit")}
            </Button>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default ReviewWidget;
