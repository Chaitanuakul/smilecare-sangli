import { useLanguage } from "@/contexts/LanguageContext";

const MapSection = () => {
  const { t } = useLanguage();

  return (
    <section id="location" className="bg-sky py-16 md:py-24">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary text-center mb-8">{t("map.title")}</h2>
        <div className="max-w-4xl mx-auto rounded-xl overflow-hidden shadow-card border border-border/50">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d122282.42907433567!2d74.49871524414064!3d16.85453420000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc1194f22b06367%3A0x6d9dafe4a2a3b1da!2sSangli%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
            width="100%"
            height="400"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="SmileCare Dental Clinic - Sangli"
          />
        </div>
      </div>
    </section>
  );
};

export default MapSection;
