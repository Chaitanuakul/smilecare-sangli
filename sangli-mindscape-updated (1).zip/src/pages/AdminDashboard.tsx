import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { isAdminAuthenticated, adminLogout, useClinicStore, updateStore, type Appointment } from "@/stores/clinicStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import {
  LayoutDashboard, CalendarDays, FileEdit, MessageSquare,
  Image, Settings, LogOut, Trash2, Plus, Download, ChevronUp, ChevronDown
} from "lucide-react";

type Tab = "dashboard" | "appointments" | "content" | "testimonials" | "gallery" | "settings";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [store, setStore] = useClinicStore();
  const [tab, setTab] = useState<Tab>("dashboard");

  useEffect(() => {
    if (!isAdminAuthenticated()) navigate("/admin/login", { replace: true });
  }, [navigate]);

  const handleLogout = () => { adminLogout(); navigate("/admin/login"); };

  const tabs: { key: Tab; label: string; icon: React.ElementType }[] = [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { key: "appointments", label: "Appointments", icon: CalendarDays },
    { key: "content", label: "Content Editor", icon: FileEdit },
    { key: "testimonials", label: "Testimonials", icon: MessageSquare },
    { key: "gallery", label: "Gallery", icon: Image },
    { key: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen flex bg-muted/20">
      {/* Sidebar */}
      <aside className="w-56 bg-card border-r border-border flex flex-col shrink-0 hidden md:flex">
        <div className="p-4 border-b border-border">
          <h2 className="font-heading font-bold text-primary text-lg">SmileCare Admin</h2>
        </div>
        <nav className="flex-1 p-2 space-y-1">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button key={t.key} onClick={() => setTab(t.key)}
                className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  tab === t.key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
                }`}>
                <Icon className="h-4 w-4" /> {t.label}
              </button>
            );
          })}
        </nav>
        <div className="p-3 border-t border-border">
          <Button variant="ghost" size="sm" onClick={handleLogout} className="w-full justify-start text-destructive">
            <LogOut className="h-4 w-4 mr-2" /> Logout
          </Button>
        </div>
      </aside>

      {/* Mobile tab bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border flex overflow-x-auto">
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`flex-1 min-w-[60px] flex flex-col items-center gap-0.5 py-2 text-[10px] font-medium ${
                tab === t.key ? "text-primary" : "text-muted-foreground"
              }`}>
              <Icon className="h-4 w-4" /> {t.label.split(" ")[0]}
            </button>
          );
        })}
      </div>

      {/* Main */}
      <main className="flex-1 p-4 md:p-6 overflow-auto pb-20 md:pb-6">
        {tab === "dashboard" && <DashboardTab store={store} />}
        {tab === "appointments" && <AppointmentsTab store={store} />}
        {tab === "content" && <ContentEditorTab store={store} />}
        {tab === "testimonials" && <TestimonialsTab store={store} />}
        {tab === "gallery" && <GalleryTab />}
        {tab === "settings" && <SettingsTab store={store} />}
      </main>
    </div>
  );
};

/* ================= DASHBOARD TAB ================= */
function DashboardTab({ store }: { store: ReturnType<typeof useClinicStore>[0] }) {
  const thisMonth = store.appointments.filter((a) => {
    const d = new Date(a.createdAt);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const pending = store.appointments.filter((a) => a.status === "pending").length;

  return (
    <div>
      <h1 className="font-heading text-2xl font-bold mb-6">Dashboard</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Appointments (This Month)" value={thisMonth.length} />
        <StatCard label="Pending Confirmations" value={pending} />
        <StatCard label="Total Reviews" value={store.reviews.length} />
        <div className="bg-card rounded-xl p-4 border border-border shadow-sm">
          <p className="text-sm text-muted-foreground mb-2">Emergency Banner</p>
          <div className="flex items-center gap-2">
            <Switch checked={store.emergencyEnabled} onCheckedChange={(v) => updateStore({ emergencyEnabled: v })} />
            <span className="text-sm font-medium">{store.emergencyEnabled ? "ON" : "OFF"}</span>
          </div>
        </div>
      </div>
      <h2 className="font-heading text-lg font-semibold mb-3">Recent Appointments</h2>
      <div className="bg-card rounded-xl border border-border overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead><TableHead>Phone</TableHead><TableHead>Service</TableHead>
              <TableHead>Time</TableHead><TableHead>Date</TableHead><TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {store.appointments.slice(-5).reverse().map((a) => (
              <TableRow key={a.id}>
                <TableCell className="font-medium">{a.name}</TableCell>
                <TableCell>{a.phone}</TableCell>
                <TableCell>{a.service}</TableCell>
                <TableCell>{a.time}</TableCell>
                <TableCell>{a.date}</TableCell>
                <TableCell>
                  <StatusBadge status={a.status} appointmentId={a.id} />
                </TableCell>
              </TableRow>
            ))}
            {store.appointments.length === 0 && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No appointments yet</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      <div className="mt-6">
        <h2 className="font-heading text-lg font-semibold mb-3">Wait Time</h2>
        <div className="flex items-center gap-3">
          <Input type="number" className="w-24" value={store.waitTime}
            onChange={(e) => updateStore({ waitTime: parseInt(e.target.value) || 0 })} />
          <span className="text-sm text-muted-foreground">minutes</span>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="bg-card rounded-xl p-4 border border-border shadow-sm">
      <p className="text-sm text-muted-foreground mb-1">{label}</p>
      <p className="text-3xl font-heading font-bold text-primary">{value}</p>
    </div>
  );
}

function StatusBadge({ status, appointmentId }: { status: string; appointmentId: string }) {
  const [store] = useClinicStore();
  const colors: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-800",
    confirmed: "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
  };
  const nextStatus: Record<string, string> = { pending: "confirmed", confirmed: "completed", completed: "pending" };
  const handleClick = () => {
    const updated = store.appointments.map((a) =>
      a.id === appointmentId ? { ...a, status: nextStatus[a.status] as Appointment["status"] } : a
    );
    updateStore({ appointments: updated });
  };
  return (
    <button onClick={handleClick} className={`px-2.5 py-1 rounded-full text-xs font-semibold capitalize ${colors[status] || ""}`}>
      {status}
    </button>
  );
}

/* ================= APPOINTMENTS TAB ================= */
function AppointmentsTab({ store }: { store: ReturnType<typeof useClinicStore>[0] }) {
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterService, setFilterService] = useState("all");

  const filtered = store.appointments.filter((a) => {
    if (filterStatus !== "all" && a.status !== filterStatus) return false;
    if (filterService !== "all" && a.service !== filterService) return false;
    return true;
  }).reverse();

  const exportCSV = () => {
    const headers = ["Name", "Phone", "Service", "Time", "Date", "Status", "Mood"];
    const rows = filtered.map((a) => [a.name, a.phone, a.service, a.time, a.date, a.status, a.mood || ""]);
    const csv = [headers, ...rows].map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = "appointments.csv"; link.click();
    URL.revokeObjectURL(url);
  };

  const deleteAppointment = (id: string) => {
    updateStore({ appointments: store.appointments.filter((a) => a.id !== id) });
    toast.success("Appointment deleted");
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-heading text-2xl font-bold">Appointments</h1>
        <Button onClick={exportCSV} variant="outline" size="sm"><Download className="h-4 w-4 mr-1" /> Export CSV</Button>
      </div>
      <div className="flex gap-3 mb-4 flex-wrap">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="confirmed">Confirmed</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterService} onValueChange={setFilterService}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Services</SelectItem>
            {["cleaning", "braces", "rootcanal", "implant", "checkup", "kids"].map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="bg-card rounded-xl border border-border overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead><TableHead>Phone</TableHead><TableHead>Service</TableHead>
              <TableHead>Time</TableHead><TableHead>Date</TableHead><TableHead>Status</TableHead><TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((a) => (
              <TableRow key={a.id}>
                <TableCell className="font-medium">{a.name}</TableCell>
                <TableCell>{a.phone}</TableCell>
                <TableCell className="capitalize">{a.service}</TableCell>
                <TableCell>{a.time}</TableCell>
                <TableCell>{a.date}</TableCell>
                <TableCell><StatusBadge status={a.status} appointmentId={a.id} /></TableCell>
                <TableCell>
                  <Button variant="ghost" size="icon" onClick={() => deleteAppointment(a.id)} className="text-destructive h-8 w-8">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && (
              <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No appointments found</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

/* ================= CONTENT EDITOR TAB ================= */
function ContentEditorTab({ store }: { store: ReturnType<typeof useClinicStore>[0] }) {
  const [overrides, setOverrides] = useState<Record<string, Record<string, string>>>(store.textOverrides || {});
  const [phone, setPhone] = useState(store.phone);
  const [whatsapp, setWhatsapp] = useState(store.whatsapp);
  const [prices, setPrices] = useState(store.treatmentPrices);

  const setOverride = (key: string, lang: string, value: string) => {
    setOverrides((prev) => ({ ...prev, [key]: { ...prev[key], [lang]: value } }));
  };

  const getVal = (key: string, lang: string) => overrides[key]?.[lang] || "";

  const save = () => {
    updateStore({ textOverrides: overrides, phone, whatsapp, treatmentPrices: prices });
    toast.success("Content saved!");
  };

  const fields = [
    { section: "Hero", keys: [
      { key: "nav.clinic", label: "Clinic Name" },
      { key: "hero.tagline", label: "Tagline" },
      { key: "hero.subtitle", label: "Subtitle" },
    ]},
    { section: "Doctor Info", keys: [
      { key: "about.name", label: "Doctor Name" },
      { key: "about.qual", label: "Qualifications" },
      { key: "about.exp", label: "Experience" },
      { key: "about.bio", label: "Bio", multiline: true },
    ]},
    { section: "Footer", keys: [
      { key: "footer.timing", label: "Timings" },
      { key: "footer.sunday", label: "Sunday Note" },
      { key: "footer.address", label: "Address" },
    ]},
    { section: "Emergency", keys: [
      { key: "emergency.text", label: "Banner Text" },
    ]},
  ];

  const serviceKeys = ["cleaning", "rootcanal", "braces", "implants", "whitening", "kids"];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-heading text-2xl font-bold">Content Editor</h1>
        <Button onClick={save} className="gradient-primary text-primary-foreground">Save Changes</Button>
      </div>

      <div className="space-y-8">
        {/* Phone & WhatsApp */}
        <Section title="Contact Numbers">
          <div className="grid sm:grid-cols-2 gap-4">
            <div><Label>Phone</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
            <div><Label>WhatsApp (without +)</Label><Input value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} /></div>
          </div>
        </Section>

        {fields.map((section) => (
          <Section key={section.section} title={section.section}>
            {section.keys.map((f) => (
              <div key={f.key} className="mb-4">
                <Label className="text-xs font-semibold text-muted-foreground uppercase">{f.label}</Label>
                <div className="grid sm:grid-cols-2 gap-2 mt-1">
                  {(f as { multiline?: boolean }).multiline ? (
                    <>
                      <Textarea placeholder="English" value={getVal(f.key, "en")} onChange={(e) => setOverride(f.key, "en", e.target.value)} rows={3} />
                      <Textarea placeholder="मराठी" value={getVal(f.key, "mr")} onChange={(e) => setOverride(f.key, "mr", e.target.value)} rows={3} />
                    </>
                  ) : (
                    <>
                      <Input placeholder="English" value={getVal(f.key, "en")} onChange={(e) => setOverride(f.key, "en", e.target.value)} />
                      <Input placeholder="मराठी" value={getVal(f.key, "mr")} onChange={(e) => setOverride(f.key, "mr", e.target.value)} />
                    </>
                  )}
                </div>
              </div>
            ))}
          </Section>
        ))}

        {/* Services */}
        <Section title="Services (Name & Description)">
          {serviceKeys.map((key) => (
            <div key={key} className="mb-4 p-3 bg-muted/30 rounded-lg">
              <p className="text-xs font-bold uppercase text-muted-foreground mb-2">{key}</p>
              <div className="grid sm:grid-cols-2 gap-2 mb-2">
                <Input placeholder="Name (EN)" value={getVal(`svc.${key}`, "en")} onChange={(e) => setOverride(`svc.${key}`, "en", e.target.value)} />
                <Input placeholder="Name (MR)" value={getVal(`svc.${key}`, "mr")} onChange={(e) => setOverride(`svc.${key}`, "mr", e.target.value)} />
              </div>
              <div className="grid sm:grid-cols-2 gap-2">
                <Textarea placeholder="Description (EN)" value={getVal(`svc.${key}Desc`, "en")} onChange={(e) => setOverride(`svc.${key}Desc`, "en", e.target.value)} rows={2} />
                <Textarea placeholder="Description (MR)" value={getVal(`svc.${key}Desc`, "mr")} onChange={(e) => setOverride(`svc.${key}Desc`, "mr", e.target.value)} rows={2} />
              </div>
            </div>
          ))}
        </Section>

        {/* Treatment Prices */}
        <Section title="Treatment Prices (₹)">
          {Object.entries(prices).map(([key, val]) => (
            <div key={key} className="flex items-center gap-3 mb-2">
              <span className="text-sm font-medium w-24 capitalize">{key}</span>
              <Input type="number" className="w-28" value={val.min} onChange={(e) => setPrices({ ...prices, [key]: { ...val, min: Number(e.target.value) } })} />
              <span className="text-muted-foreground">to</span>
              <Input type="number" className="w-28" value={val.max} onChange={(e) => setPrices({ ...prices, [key]: { ...val, max: Number(e.target.value) } })} />
            </div>
          ))}
        </Section>

        {/* Stats */}
        <Section title="Stats (Override)">
          <div className="grid sm:grid-cols-3 gap-3">
            <div><Label>Patients Count (EN)</Label><Input placeholder="500+" value={getVal("stats.patientsVal", "en")} onChange={(e) => setOverride("stats.patientsVal", "en", e.target.value)} /></div>
            <div><Label>Years (EN)</Label><Input placeholder="10+" value={getVal("stats.expVal", "en")} onChange={(e) => setOverride("stats.expVal", "en", e.target.value)} /></div>
            <div><Label>Painless % (EN)</Label><Input placeholder="98%" value={getVal("stats.painVal", "en")} onChange={(e) => setOverride("stats.painVal", "en", e.target.value)} /></div>
          </div>
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-card rounded-xl border border-border p-4 md:p-6">
      <h3 className="font-heading font-semibold text-lg mb-4">{title}</h3>
      {children}
    </div>
  );
}

/* ================= TESTIMONIALS TAB ================= */
function TestimonialsTab({ store }: { store: ReturnType<typeof useClinicStore>[0] }) {
  const [newTest, setNewTest] = useState({ nameEn: "", nameMr: "", textEn: "", textMr: "", rating: 5 });

  const testimonials = store.textOverrides?.["_testimonials"]
    ? JSON.parse(store.textOverrides["_testimonials"]["data"] || "[]")
    : [];

  const saveTestimonials = (data: typeof testimonials) => {
    const overrides = { ...store.textOverrides, _testimonials: { data: JSON.stringify(data) } };
    updateStore({ textOverrides: overrides });
  };

  const addTestimonial = () => {
    if (!newTest.nameEn || !newTest.textEn) return toast.error("Fill in at least English fields");
    const updated = [...testimonials, { id: Date.now().toString(), ...newTest }];
    saveTestimonials(updated);
    setNewTest({ nameEn: "", nameMr: "", textEn: "", textMr: "", rating: 5 });
    toast.success("Testimonial added");
  };

  const deleteTestimonial = (id: string) => {
    saveTestimonials(testimonials.filter((t: { id: string }) => t.id !== id));
    toast.success("Testimonial deleted");
  };

  return (
    <div>
      <h1 className="font-heading text-2xl font-bold mb-6">Testimonials</h1>

      <div className="bg-card rounded-xl border border-border p-4 mb-6">
        <h3 className="font-semibold mb-3">Add New Testimonial</h3>
        <div className="grid sm:grid-cols-2 gap-3 mb-3">
          <Input placeholder="Name (English)" value={newTest.nameEn} onChange={(e) => setNewTest({ ...newTest, nameEn: e.target.value })} />
          <Input placeholder="Name (Marathi)" value={newTest.nameMr} onChange={(e) => setNewTest({ ...newTest, nameMr: e.target.value })} />
          <Textarea placeholder="Review (English)" value={newTest.textEn} onChange={(e) => setNewTest({ ...newTest, textEn: e.target.value })} rows={2} />
          <Textarea placeholder="Review (Marathi)" value={newTest.textMr} onChange={(e) => setNewTest({ ...newTest, textMr: e.target.value })} rows={2} />
        </div>
        <div className="flex items-center gap-3">
          <Label>Rating:</Label>
          <Select value={String(newTest.rating)} onValueChange={(v) => setNewTest({ ...newTest, rating: Number(v) })}>
            <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
            <SelectContent>{[1, 2, 3, 4, 5].map((n) => <SelectItem key={n} value={String(n)}>{n} ★</SelectItem>)}</SelectContent>
          </Select>
          <Button onClick={addTestimonial} size="sm"><Plus className="h-4 w-4 mr-1" /> Add</Button>
        </div>
      </div>

      <div className="space-y-3">
        {testimonials.map((t: { id: string; nameEn: string; textEn: string; rating: number }) => (
          <div key={t.id} className="bg-card rounded-xl border border-border p-4 flex justify-between items-start">
            <div>
              <p className="font-medium">{t.nameEn} — {"★".repeat(t.rating)}</p>
              <p className="text-sm text-muted-foreground mt-1">{t.textEn}</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => deleteTestimonial(t.id)} className="text-destructive">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
        <p className="text-sm text-muted-foreground">Note: The 3 default testimonials are always shown. Additional ones added here will appear alongside them.</p>
      </div>
    </div>
  );
}

/* ================= GALLERY TAB ================= */
function GalleryTab() {
  return (
    <div>
      <h1 className="font-heading text-2xl font-bold mb-6">Gallery</h1>
      <div className="bg-card rounded-xl border border-border p-6">
        <p className="text-muted-foreground mb-4">Before/After gallery images are currently managed as static assets.</p>
        <p className="text-sm text-muted-foreground">To add new images, upload them to the project's <code className="bg-muted px-1 rounded">src/assets/</code> folder and reference them in the GallerySection component.</p>
        <p className="text-sm text-muted-foreground mt-2">For dynamic image management, consider connecting a backend storage service.</p>
      </div>
    </div>
  );
}

/* ================= SETTINGS TAB ================= */
function SettingsTab({ store }: { store: ReturnType<typeof useClinicStore>[0] }) {
  const [newPassword, setNewPassword] = useState("");
  const [social, setSocial] = useState(store.socialLinks);
  const [seoTitle, setSeoTitle] = useState(store.seoTitle);
  const [seoDesc, setSeoDesc] = useState(store.seoDescription);

  const saveSettings = () => {
    const updates: Partial<typeof store> = { socialLinks: social, seoTitle, seoDescription: seoDesc };
    if (newPassword.trim()) updates.adminPassword = newPassword.trim();
    updateStore(updates);
    setNewPassword("");
    toast.success("Settings saved!");
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-heading text-2xl font-bold">Settings</h1>
        <Button onClick={saveSettings} className="gradient-primary text-primary-foreground">Save</Button>
      </div>
      <div className="space-y-6">
        <Section title="Change Admin Password">
          <Input type="password" placeholder="New password (leave empty to keep current)" value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)} className="max-w-sm" />
        </Section>

        <Section title="Maintenance Mode">
          <div className="flex items-center gap-3">
            <Switch checked={store.maintenanceMode} onCheckedChange={(v) => updateStore({ maintenanceMode: v })} />
            <span className="text-sm">{store.maintenanceMode ? "ON — Visitors see maintenance page" : "OFF — Website is live"}</span>
          </div>
        </Section>

        <Section title="SEO Settings">
          <div className="space-y-3">
            <div><Label>Page Title</Label><Input value={seoTitle} onChange={(e) => setSeoTitle(e.target.value)} /></div>
            <div><Label>Meta Description</Label><Textarea value={seoDesc} onChange={(e) => setSeoDesc(e.target.value)} rows={2} /></div>
          </div>
        </Section>

        <Section title="Social Media Links">
          <div className="space-y-3">
            <div><Label>Facebook URL</Label><Input value={social.facebook} onChange={(e) => setSocial({ ...social, facebook: e.target.value })} /></div>
            <div><Label>Instagram URL</Label><Input value={social.instagram} onChange={(e) => setSocial({ ...social, instagram: e.target.value })} /></div>
            <div><Label>Google Business Profile URL</Label><Input value={social.google} onChange={(e) => setSocial({ ...social, google: e.target.value })} /></div>
          </div>
        </Section>
      </div>
    </div>
  );
}

export default AdminDashboard;
