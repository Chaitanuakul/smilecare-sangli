import { useClinicStore } from "@/stores/clinicStore";
import MaintenanceMode from "@/components/MaintenanceMode";
import ScrollProgress from "@/components/ScrollProgress";
import EmergencyBanner from "@/components/EmergencyBanner";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import StatsCounter from "@/components/StatsCounter";
import ServicesSection from "@/components/ServicesSection";
import CostEstimator from "@/components/CostEstimator";
import GallerySection from "@/components/GallerySection";
import PatientJourney from "@/components/PatientJourney";
import AboutSection from "@/components/AboutSection";
import WhyChooseUs from "@/components/WhyChooseUs";
import TestimonialsSection from "@/components/TestimonialsSection";
import ReviewWidget from "@/components/ReviewWidget";
import FAQSection from "@/components/FAQSection";
import MapSection from "@/components/MapSection";
import Footer from "@/components/Footer";
import QuickLinksBar from "@/components/QuickLinksBar";
import SymptomHelper from "@/components/SymptomHelper";
import { useEffect } from "react";

const Index = () => {
  const [store] = useClinicStore();

  // SEO: update document title and meta
  useEffect(() => {
    if (store.seoTitle) document.title = store.seoTitle;
    const meta = document.querySelector('meta[name="description"]');
    if (meta && store.seoDescription) meta.setAttribute("content", store.seoDescription);
  }, [store.seoTitle, store.seoDescription]);

  if (store.maintenanceMode) return <MaintenanceMode />;

  return (
    <div className="min-h-screen">
      <ScrollProgress />
      <EmergencyBanner />
      <Navbar />
      <HeroSection />
      <StatsCounter />
      <ServicesSection />
      <CostEstimator />
      <GallerySection />
      <PatientJourney />
      <AboutSection />
      <WhyChooseUs />
      <TestimonialsSection />
      <ReviewWidget />
      <FAQSection />
      <MapSection />
      <Footer />
      <QuickLinksBar />
      <SymptomHelper />
    </div>
  );
};

export default Index;
