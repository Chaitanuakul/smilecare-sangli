import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

type Language = "en" | "mr";

interface LanguageContextType {
  lang: Language;
  toggle: () => void;
  t: (key: string) => string;
}

const T: Record<string, Record<Language, string>> = {
  // Emergency
  "emergency.text": { en: "Dental Emergency? Call Now — 24hr", mr: "दंत आणीबाणी? आता कॉल करा — २४ तास" },
  // Navbar
  "nav.clinic": { en: "SmileCare Dental", mr: "स्माइलकेअर डेंटल" },
  "nav.book": { en: "Book Appointment", mr: "अपॉइंटमेंट बुक करा" },
  "nav.lang": { en: "मराठी", mr: "English" },
  // Hero
  "hero.tagline": { en: "Healthy Smiles Start Here", mr: "निरोगी हास्य इथून सुरू होते" },
  "hero.subtitle": { en: "Advanced dental care with gentle hands in Sangli, Maharashtra. Your comfort is our priority.", mr: "सांगली, महाराष्ट्रातील सौम्य हातांनी प्रगत दंत काळजी. तुमचा आराम ही आमची प्राथमिकता." },
  "hero.cta": { en: "Book Your Visit", mr: "तुमची भेट बुक करा" },
  "hero.call": { en: "Call Now", mr: "आता कॉल करा" },
  // Stats
  "stats.patients": { en: "Happy Patients", mr: "आनंदी रुग्ण" },
  "stats.experience": { en: "Years Experience", mr: "वर्षांचा अनुभव" },
  "stats.painless": { en: "Painless", mr: "वेदनारहित" },
  // Services
  "services.title": { en: "Our Dental Services", mr: "आमच्या दंत सेवा" },
  "services.subtitle": { en: "Comprehensive care for the whole family", mr: "संपूर्ण कुटुंबासाठी सर्वसमावेशक काळजी" },
  "svc.cleaning": { en: "Teeth Cleaning", mr: "दात स्वच्छता" },
  "svc.cleaningDesc": { en: "Professional scaling and polishing to keep your teeth sparkling clean and gums healthy.", mr: "तुमचे दात चमकदार स्वच्छ आणि हिरड्या निरोगी ठेवण्यासाठी व्यावसायिक स्केलिंग आणि पॉलिशिंग." },
  "svc.rootcanal": { en: "Root Canal", mr: "रूट कॅनॉल" },
  "svc.rootcanalDesc": { en: "Painless root canal treatment using advanced rotary instruments. Save your natural tooth!", mr: "प्रगत रोटरी उपकरणे वापरून वेदनारहित रूट कॅनॉल उपचार. तुमचा नैसर्गिक दात वाचवा!" },
  "svc.braces": { en: "Braces & Aligners", mr: "ब्रेसेस आणि अलाइनर" },
  "svc.bracesDesc": { en: "Metal braces, ceramic braces, and clear aligners for a perfectly aligned smile.", mr: "परिपूर्ण संरेखित हास्यासाठी मेटल ब्रेसेस, सिरॅमिक ब्रेसेस आणि क्लिअर अलाइनर." },
  "svc.implants": { en: "Dental Implants", mr: "दंत रोपण" },
  "svc.implantsDesc": { en: "Permanent tooth replacement with titanium implants. Look and feel like natural teeth.", mr: "टायटॅनियम इम्प्लांटसह कायमस्वरूपी दात बदलणे. नैसर्गिक दातांसारखे दिसतात आणि वाटतात." },
  "svc.whitening": { en: "Teeth Whitening", mr: "दात पांढरे करणे" },
  "svc.whiteningDesc": { en: "In-office and at-home whitening treatments for a brighter, more confident smile.", mr: "उजळ, अधिक आत्मविश्वासपूर्ण हास्यासाठी ऑफिसमध्ये आणि घरी व्हाइटनिंग उपचार." },
  "svc.kids": { en: "Kids Dentistry", mr: "बाल दंतचिकित्सा" },
  "svc.kidsDesc": { en: "Fun, gentle dental care for children. We make dental visits enjoyable for little ones!", mr: "मुलांसाठी मजेदार, सौम्य दंत काळजी. आम्ही लहान मुलांसाठी दंत भेटी आनंददायी बनवतो!" },
  // Gallery
  "gallery.title": { en: "Smile Transformations", mr: "हास्य परिवर्तन" },
  "gallery.subtitle": { en: "Drag the slider to see the transformation", mr: "परिवर्तन पाहण्यासाठी स्लाइडर ड्रॅग करा" },
  "gallery.before": { en: "Before", mr: "आधी" },
  "gallery.after": { en: "After", mr: "नंतर" },
  // About
  "about.title": { en: "Meet Your Dentist", mr: "तुमच्या दंतवैद्यांना भेटा" },
  "about.name": { en: "Dr. Amit Patil", mr: "डॉ. अमित पाटील" },
  "about.qual": { en: "BDS, MDS (Prosthodontics)", mr: "BDS, MDS (प्रोस्थोडोंटिक्स)" },
  "about.exp": { en: "10+ Years Experience", mr: "१०+ वर्षांचा अनुभव" },
  "about.bio": { en: "Dr. Amit Patil is a highly skilled dentist serving Sangli and surrounding areas for over a decade. He completed his MDS from a premier dental college and stays updated with the latest techniques in painless dentistry.", mr: "डॉ. अमित पाटील हे एक अत्यंत कुशल दंतचिकित्सक आहेत जे एका दशकाहून अधिक काळ सांगली आणि आसपासच्या भागात सेवा देत आहेत." },
  // Why Choose
  "why.title": { en: "Why Choose Us", mr: "आम्हाला का निवडा" },
  "why.painless": { en: "Painless Treatment", mr: "वेदनारहित उपचार" },
  "why.painlessDesc": { en: "Advanced anaesthesia and gentle techniques ensure you feel zero pain during procedures.", mr: "प्रगत भूल आणि सौम्य तंत्रे सुनिश्चित करतात की प्रक्रियेदरम्यान तुम्हाला शून्य वेदना जाणवतात." },
  "why.modern": { en: "Modern Equipment", mr: "आधुनिक उपकरणे" },
  "why.modernDesc": { en: "Digital X-rays, laser dentistry, and imported materials for world-class treatment.", mr: "जागतिक दर्जाच्या उपचारांसाठी डिजिटल एक्स-रे, लेसर दंतचिकित्सा आणि आयात केलेली सामग्री." },
  "why.affordable": { en: "Affordable Fees", mr: "परवडणारे शुल्क" },
  "why.affordableDesc": { en: "Quality dental care at fair prices. EMI options available for major treatments.", mr: "वाजवी किमतीत दर्जेदार दंत काळजी. प्रमुख उपचारांसाठी EMI पर्याय उपलब्ध." },
  // Testimonials
  "test.title": { en: "Patient Stories", mr: "रुग्णांच्या कथा" },
  "test.1.text": { en: "I was terrified of dentists my whole life, but Dr. Patil made me feel so comfortable. Got my root canal done painlessly!", mr: "मला आयुष्यभर दंतवैद्यांची भीती वाटायची, पण डॉ. पाटीलांनी मला खूप आरामदायी वाटायला लावले!" },
  "test.1.name": { en: "Meena S.", mr: "मीना स." },
  "test.2.text": { en: "Best dental clinic in Sangli! The clinic is spotlessly clean and the staff is very friendly.", mr: "सांगलीतील सर्वोत्तम दंत क्लिनिक! क्लिनिक अत्यंत स्वच्छ आहे आणि कर्मचारी खूप मैत्रीपूर्ण आहेत." },
  "test.2.name": { en: "Rahul J.", mr: "राहुल ज." },
  "test.3.text": { en: "Got my teeth whitening done here and the results are amazing. Very professional and trustworthy.", mr: "इथे माझे दात पांढरे करून घेतले आणि परिणाम अप्रतिम आहेत. अत्यंत व्यावसायिक आणि विश्वासार्ह." },
  "test.3.name": { en: "Sneha K.", mr: "स्नेहा क." },
  // Map
  "map.title": { en: "Visit Our Clinic", mr: "आमच्या क्लिनिकला भेट द्या" },
  // Quick Links
  "ql.book": { en: "Book", mr: "बुक करा" },
  "ql.call": { en: "Call", mr: "कॉल" },
  "ql.whatsapp": { en: "WhatsApp", mr: "WhatsApp" },
  "ql.map": { en: "Map", mr: "नकाशा" },
  // Footer
  "footer.timing": { en: "Mon–Sat: 9:30 AM – 1:30 PM, 5:00 PM – 9:00 PM", mr: "सोम–शनि: सकाळी ९:३० – दुपारी १:३०, संध्याकाळी ५:०० – रात्री ९:००" },
  "footer.sunday": { en: "Sunday: By Appointment Only", mr: "रविवार: फक्त अपॉइंटमेंटने" },
  "footer.address": { en: "SmileCare Dental Clinic, Vishrambag Main Road, Sangli, Maharashtra 416415", mr: "स्माइलकेअर डेंटल क्लिनिक, विश्रामबाग मुख्य रस्ता, सांगली, महाराष्ट्र ४१६४१५" },
  "footer.rights": { en: "All rights reserved", mr: "सर्व हक्क राखीव" },
  // Appointment
  "apt.title": { en: "Book an Appointment", mr: "अपॉइंटमेंट बुक करा" },
  "apt.name": { en: "Full Name", mr: "पूर्ण नाव" },
  "apt.namePh": { en: "Your full name", mr: "तुमचे पूर्ण नाव" },
  "apt.phone": { en: "Phone Number", mr: "फोन नंबर" },
  "apt.phonePh": { en: "Your phone number", mr: "तुमचा फोन नंबर" },
  "apt.service": { en: "Service Needed", mr: "आवश्यक सेवा" },
  "apt.servicePh": { en: "Select a service", mr: "सेवा निवडा" },
  "apt.time": { en: "Preferred Time Slot", mr: "पसंतीची वेळ" },
  "apt.timePh": { en: "Select time slot", mr: "वेळ निवडा" },
  "apt.submit": { en: "Book Now", mr: "आता बुक करा" },
  "apt.success": { en: "Appointment booked! We'll call you to confirm.", mr: "अपॉइंटमेंट बुक झाली! आम्ही तुम्हाला कन्फर्म करण्यासाठी कॉल करू." },
  "apt.cleaning": { en: "Teeth Cleaning", mr: "दात स्वच्छता" },
  "apt.braces": { en: "Braces / Aligners", mr: "ब्रेसेस / अलाइनर" },
  "apt.rootcanal": { en: "Root Canal", mr: "रूट कॅनॉल" },
  "apt.implant": { en: "Dental Implant", mr: "दंत रोपण" },
  "apt.checkup": { en: "General Checkup", mr: "सामान्य तपासणी" },
  "apt.kids": { en: "Kids Dentistry", mr: "बाल दंतचिकित्सा" },
  "apt.morning": { en: "Morning (9:30–1:30)", mr: "सकाळ (९:३०–१:३०)" },
  "apt.evening": { en: "Evening (5:00–9:00)", mr: "संध्याकाळ (५:००–९:००)" },
  // FAQ
  "faq.title": { en: "Frequently Asked Questions", mr: "वारंवार विचारले जाणारे प्रश्न" },
  "faq.1.q": { en: "Is the root canal treatment painful?", mr: "रूट कॅनॉल उपचार वेदनादायक आहे का?" },
  "faq.1.a": { en: "Not at all! We use advanced anaesthesia and rotary instruments that make the procedure virtually painless.", mr: "अजिबात नाही! आम्ही प्रगत भूल आणि रोटरी उपकरणे वापरतो जे प्रक्रिया जवळजवळ वेदनारहित बनवतात." },
  "faq.2.q": { en: "How much does teeth cleaning cost?", mr: "दात स्वच्छतेचा खर्च किती आहे?" },
  "faq.2.a": { en: "Teeth cleaning starts from ₹500. The exact cost depends on the level of scaling required.", mr: "दात स्वच्छता ₹५०० पासून सुरू होते. अचूक खर्च स्केलिंगच्या पातळीवर अवलंबून असतो." },
  "faq.3.q": { en: "Do you offer EMI for braces?", mr: "तुम्ही ब्रेसेससाठी EMI देता का?" },
  "faq.3.a": { en: "Yes! We offer easy EMI options for braces, implants, and other major treatments.", mr: "हो! आम्ही ब्रेसेस, इम्प्लांट्स आणि इतर प्रमुख उपचारांसाठी सुलभ EMI पर्याय देतो." },
  "faq.4.q": { en: "What age should children first visit a dentist?", mr: "मुलांनी प्रथम दंतवैद्याला कधी भेट द्यावी?" },
  "faq.4.a": { en: "We recommend bringing children for their first dental visit by age 1 or when the first tooth appears.", mr: "आम्ही शिफारस करतो की मुलांना वयाच्या १ वर्षापर्यंत किंवा पहिला दात आल्यावर पहिल्या दंत भेटीसाठी आणावे." },
  "faq.5.q": { en: "Is teeth whitening safe?", mr: "दात पांढरे करणे सुरक्षित आहे का?" },
  "faq.5.a": { en: "Absolutely! Professional teeth whitening is safe and effective when done by a qualified dentist.", mr: "अर्थातच! पात्र दंतवैद्याने केल्यावर व्यावसायिक दात पांढरे करणे सुरक्षित आणि प्रभावी आहे." },
  // Mood-based booking
  "mood.title": { en: "How are you feeling about your visit?", mr: "तुमच्या भेटीबद्दल तुम्हाला कसे वाटते?" },
  "mood.nervous": { en: "Nervous", mr: "चिंताग्रस्त" },
  "mood.excited": { en: "Excited", mr: "उत्साही" },
  "mood.unsure": { en: "Unsure", mr: "अनिश्चित" },
  "mood.justdoit": { en: "Just get it done", mr: "फक्त करून टाका" },
  "mood.nervousMsg": { en: "We totally get it — our team is extra gentle with nervous patients. Dr. Patil will explain every step before doing anything.", mr: "आम्हाला पूर्णपणे समजते — आमची टीम चिंताग्रस्त रुग्णांसोबत अतिशय सौम्य असते." },
  "mood.excitedMsg": { en: "Love the energy! Let's get your smile sorted. 😄", mr: "उत्साह आवडला! तुमचे हास्य व्यवस्थित करूया. 😄" },
  "mood.unsureMsg": { en: "No worries! We'll guide you through everything. A simple consultation will help us understand what you need.", mr: "काळजी नाही! आम्ही तुम्हाला सर्वकाही समजावून सांगू." },
  "mood.justdoitMsg": { en: "We like your style! Quick, efficient, painless — that's our promise. 💪", mr: "तुमची स्टाइल आवडली! जलद, कार्यक्षम, वेदनारहित — हे आमचे वचन. 💪" },
  "mood.continue": { en: "Continue to Booking →", mr: "बुकिंगकडे पुढे जा →" },
  // Symptom Helper
  "symptom.title": { en: "SmileCare Assistant", mr: "स्माइलकेअर सहाय्यक" },
  "symptom.greeting": { en: "Hi! 👋 How can I help you today?", mr: "नमस्कार! 👋 आज मी तुम्हाला कशी मदत करू शकतो?" },
  "symptom.pain": { en: "I have tooth pain", mr: "मला दात दुखतो" },
  "symptom.straight": { en: "I want straighter teeth", mr: "मला सरळ दात हवेत" },
  "symptom.gums": { en: "My gums bleed", mr: "माझ्या हिरड्यांमधून रक्त येते" },
  "symptom.checkup": { en: "I need a checkup", mr: "मला तपासणी हवी" },
  "symptom.kidsprob": { en: "Kids tooth problem", mr: "मुलांचा दात समस्या" },
  "symptom.broken": { en: "Broken tooth", mr: "तुटलेला दात" },
  "symptom.painReply": { en: "Tooth pain can be due to cavities, infection, or sensitivity. A quick checkup will identify the cause. Most treatments are painless!", mr: "दातदुखी पोकळी, संसर्ग किंवा संवेदनशीलतेमुळे होऊ शकते. एक जलद तपासणी कारण ओळखेल!" },
  "symptom.straightReply": { en: "We offer metal braces, ceramic braces, and clear aligners! A consultation will help find the best option for you.", mr: "आम्ही मेटल ब्रेसेस, सिरॅमिक ब्रेसेस आणि क्लिअर अलाइनर देतो!" },
  "symptom.gumsReply": { en: "Bleeding gums often indicate gum disease. Professional cleaning and proper care can fix this easily.", mr: "रक्तस्राव होणाऱ्या हिरड्या सहसा हिरड्यांचा आजार दर्शवतात. व्यावसायिक स्वच्छता हे सहज ठीक करू शकते." },
  "symptom.checkupReply": { en: "Great idea! Regular checkups help catch problems early. We'll do a thorough examination and cleaning.", mr: "छान कल्पना! नियमित तपासणी समस्या लवकर पकडण्यास मदत करते." },
  "symptom.kidsReply": { en: "Kids dental care is our specialty! We make visits fun and gentle for your little ones.", mr: "बाल दंत काळजी ही आमची खासियत आहे! आम्ही लहान मुलांसाठी भेटी मजेदार बनवतो." },
  "symptom.brokenReply": { en: "Don't worry! We can fix broken teeth with bonding, crowns, or veneers. Visit us soon for best results.", mr: "काळजी करू नका! आम्ही बॉंडिंग, क्राउन किंवा व्हिनिअरने तुटलेले दात ठीक करू शकतो." },
  "symptom.book": { en: "Book for this →", mr: "यासाठी बुक करा →" },
  // Cost Estimator
  "cost.title": { en: "Get a Price Estimate", mr: "किंमत अंदाज मिळवा" },
  "cost.subtitle": { en: "Know before you go — transparent pricing", mr: "जाण्यापूर्वी जाणून घ्या — पारदर्शक किंमती" },
  "cost.select": { en: "Select a treatment", mr: "उपचार निवडा" },
  "cost.range": { en: "Estimated Cost", mr: "अंदाजित खर्च" },
  "cost.disclaimer": { en: "Final cost depends on complexity. Consultation fee: ₹200", mr: "अंतिम खर्च जटिलतेवर अवलंबून असतो. सल्ला शुल्क: ₹२००" },
  "cost.book": { en: "Book for this treatment →", mr: "या उपचारासाठी बुक करा →" },
  // Wait Time
  "wait.today": { en: "Today's wait", mr: "आजची प्रतीक्षा" },
  "wait.mins": { en: "mins", mr: "मिनिटे" },
  "wait.closed": { en: "Clinic Closed", mr: "क्लिनिक बंद" },
  // Patient Journey
  "journey.title": { en: "What to Expect at SmileCare", mr: "स्माइलकेअरमध्ये काय अपेक्षा करावी" },
  "journey.1.title": { en: "Book Online", mr: "ऑनलाइन बुक करा" },
  "journey.1.desc": { en: "Schedule your visit in seconds", mr: "काही सेकंदात तुमची भेट शेड्यूल करा" },
  "journey.2.title": { en: "Arrive & Check In", mr: "येथे या आणि चेक इन करा" },
  "journey.2.desc": { en: "Friendly staff welcomes you", mr: "मैत्रीपूर्ण कर्मचारी तुमचे स्वागत करतात" },
  "journey.3.title": { en: "Consultation", mr: "सल्लामसलत" },
  "journey.3.desc": { en: "Doctor explains everything clearly", mr: "डॉक्टर सर्वकाही स्पष्टपणे समजावतात" },
  "journey.4.title": { en: "Treatment", mr: "उपचार" },
  "journey.4.desc": { en: "Painless, modern procedures", mr: "वेदनारहित, आधुनिक प्रक्रिया" },
  "journey.5.title": { en: "Follow Up", mr: "फॉलो अप" },
  "journey.5.desc": { en: "We stay in touch for recovery", mr: "पुनर्प्राप्तीसाठी आम्ही संपर्कात राहतो" },
  // Review Widget
  "review.title": { en: "Rate Your Experience", mr: "तुमचा अनुभव रेट करा" },
  "review.name": { en: "Your Name", mr: "तुमचे नाव" },
  "review.comment": { en: "Short Comment", mr: "थोडक्यात प्रतिक्रिया" },
  "review.submit": { en: "Submit Review", mr: "समीक्षा सबमिट करा" },
  "review.success": { en: "Thank you for your review!", mr: "तुमच्या समीक्षेबद्दल धन्यवाद!" },
  "review.avg": { en: "Average Rating", mr: "सरासरी रेटिंग" },
  // Maintenance
  "maintenance.title": { en: "Under Maintenance", mr: "देखभालीखाली" },
  "maintenance.subtitle": { en: "Clinic website is being updated. Please call us directly.", mr: "क्लिनिक वेबसाइट अपडेट होत आहे. कृपया आम्हाला थेट कॉल करा." },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem("dental-lang");
    return (saved === "mr" ? "mr" : "en") as Language;
  });

  const [overrides, setOverrides] = useState<Record<string, Record<string, string>>>({});

  useEffect(() => {
    localStorage.setItem("dental-lang", lang);
  }, [lang]);

  useEffect(() => {
    const loadOverrides = () => {
      try {
        const raw = localStorage.getItem("smilecare-clinic-data");
        if (raw) {
          const parsed = JSON.parse(raw);
          setOverrides(parsed.textOverrides || {});
        }
      } catch {}
    };
    loadOverrides();
    window.addEventListener("clinic-store-update", loadOverrides);
    return () => window.removeEventListener("clinic-store-update", loadOverrides);
  }, []);

  const toggle = () => setLang((p) => (p === "en" ? "mr" : "en"));
  const t = (key: string) => {
    const override = overrides[key]?.[lang];
    if (override) return override;
    return T[key]?.[lang] || key;
  };

  return (
    <LanguageContext.Provider value={{ lang, toggle, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be inside LanguageProvider");
  return ctx;
};
