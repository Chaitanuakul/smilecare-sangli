import { useState, useEffect } from "react";

const STORE_KEY = "smilecare-clinic-data";

export interface Appointment {
  id: string;
  name: string;
  phone: string;
  service: string;
  time: string;
  date: string;
  status: "pending" | "confirmed" | "completed";
  mood?: string;
  createdAt: string;
}

export interface Review {
  id: string;
  name: string;
  text: string;
  rating: number;
  date: string;
}

export interface ClinicStore {
  appointments: Appointment[];
  reviews: Review[];
  emergencyEnabled: boolean;
  waitTime: number;
  maintenanceMode: boolean;
  seoTitle: string;
  seoDescription: string;
  socialLinks: { facebook: string; instagram: string; google: string };
  treatmentPrices: Record<string, { min: number; max: number }>;
  adminEmail: string;
  adminPassword: string;
  textOverrides: Record<string, Record<string, string>>;
  phone: string;
  whatsapp: string;
}

const defaults: ClinicStore = {
  appointments: [],
  reviews: [],
  emergencyEnabled: true,
  waitTime: 20,
  maintenanceMode: false,
  seoTitle: "SmileCare Dental Clinic – Sangli, Maharashtra",
  seoDescription: "Best dental clinic in Sangli. Painless treatment, modern equipment, affordable fees.",
  socialLinks: { facebook: "", instagram: "", google: "" },
  treatmentPrices: {
    cleaning: { min: 500, max: 1500 },
    rootcanal: { min: 3000, max: 6000 },
    braces: { min: 25000, max: 60000 },
    implants: { min: 20000, max: 40000 },
    whitening: { min: 5000, max: 12000 },
    kids: { min: 300, max: 2000 },
    checkup: { min: 200, max: 500 },
  },
  adminEmail: "ck031781@gmail.com",
  adminPassword: "416415coccoc_4C",
  textOverrides: {},
  phone: "+919876543210",
  whatsapp: "919876543210",
};

const listeners = new Set<() => void>();

export function getStore(): ClinicStore {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    return raw ? { ...defaults, ...JSON.parse(raw) } : { ...defaults };
  } catch {
    return { ...defaults };
  }
}

export function updateStore(updates: Partial<ClinicStore>) {
  const current = getStore();
  const next = { ...current, ...updates };
  localStorage.setItem(STORE_KEY, JSON.stringify(next));
  listeners.forEach((l) => l());
  window.dispatchEvent(new Event("clinic-store-update"));
}

export function isAdminAuthenticated(): boolean {
  try {
    const raw = localStorage.getItem("smilecare-admin-auth");
    if (!raw) return false;
    const auth = JSON.parse(raw);
    if (!auth.authenticated) return false;
    // Session expires after 24 hours
    if (Date.now() - auth.timestamp > 86400000) return false;
    return true;
  } catch {
    return false;
  }
}

export function adminLogin(email: string, password: string): boolean {
  const store = getStore();
  if (email === store.adminEmail && password === store.adminPassword) {
    localStorage.setItem("smilecare-admin-auth", JSON.stringify({ authenticated: true, timestamp: Date.now() }));
    return true;
  }
  return false;
}

export function adminLogout() {
  localStorage.removeItem("smilecare-admin-auth");
}

export function useClinicStore(): [ClinicStore, (updates: Partial<ClinicStore>) => void] {
  const [data, setData] = useState(getStore);

  useEffect(() => {
    const handler = () => setData(getStore());
    listeners.add(handler);
    const storageHandler = () => handler();
    window.addEventListener("clinic-store-update", storageHandler);
    return () => {
      listeners.delete(handler);
      window.removeEventListener("clinic-store-update", storageHandler);
    };
  }, []);

  return [data, updateStore];
}

export function isClinicOpen(): boolean {
  const now = new Date();
  const day = now.getDay();
  if (day === 0) return false; // Sunday
  const hour = now.getHours();
  const min = now.getMinutes();
  const t = hour * 60 + min;
  return (t >= 570 && t <= 810) || (t >= 1020 && t <= 1260); // 9:30-13:30 or 17:00-21:00
}
